package dev.appsody.starter;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/blockchain")
public class StarterApplication extends Application {
    
}
