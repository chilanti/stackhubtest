package dev.appsody.starter;

import java.io.ByteArrayInputStream;
import java.io.StringReader;

public class ConnectionConfiguration {

    private static String conn = "{\n    \"name\": \"channel1\",\n    \"description\": \"Network on IBP v2\",\n    \"version\": \"1.0.0\",\n    \"client\": {\n        \"organization\": \"org2msp\"\n    },\n    \"organizations\": {\n        \"org1msp\": {\n            \"mspid\": \"org1msp\",\n            \"peers\": []\n        },\n        \"org2msp\": {\n            \"mspid\": \"org2msp\",\n            \"peers\": [\n                \"184.172.253.205:32376\"\n            ],\n            \"certificateAuthorities\": [\n                \"184.172.253.205:32166\"\n            ]\n        }\n    },\n    \"orderers\": {\n        \"184.172.253.205:31517\": {\n            \"url\": \"grpcs://184.172.253.205:31517\",\n            \"tlsCACerts\": {\n                \"pem\": \"-----BEGIN CERTIFICATE-----\\nMIICNzCCAd6gAwIBAgIUYa3OHom+1cuPEkQMZwnQXGZJHa4wCgYIKoZIzj0EAwIw\\nbTELMAkGA1UEBhMCVVMxFzAVBgNVBAgTDk5vcnRoIENhcm9saW5hMRQwEgYDVQQK\\nEwtIeXBlcmxlZGdlcjEPMA0GA1UECxMGRmFicmljMR4wHAYDVQQDExVPcmRlcmlu\\nZ1NlcnZpY2VDQS10bHMwHhcNMjAwMjIwMTg0MjAwWhcNMzUwMjE2MTg0MjAwWjBt\\nMQswCQYDVQQGEwJVUzEXMBUGA1UECBMOTm9ydGggQ2Fyb2xpbmExFDASBgNVBAoT\\nC0h5cGVybGVkZ2VyMQ8wDQYDVQQLEwZGYWJyaWMxHjAcBgNVBAMTFU9yZGVyaW5n\\nU2VydmljZUNBLXRsczBZMBMGByqGSM49AgEGCCqGSM49AwEHA0IABDupW30xgKAF\\n7wh6EJDSvFlcJ/v6ghSVeaoxsb9gPTZPYIPO6qZNSYV6ItpoSpT2O+sRGDmxYSCG\\nGmiq4UhJE36jXDBaMA4GA1UdDwEB/wQEAwIBBjASBgNVHRMBAf8ECDAGAQH/AgEB\\nMB0GA1UdDgQWBBReprItuNIgj07lZ16Hfz69ztWoUjAVBgNVHREEDjAMhwS4rP3N\\nhwQKLAwqMAoGCCqGSM49BAMCA0cAMEQCIEvDHzoazpACSCVUWoyjwjG0nIo2CE9Y\\ny2Qqj5XrzsCPAiBulxSz8/0tZBQKwEyjA7jRg5k3ckJ/5BSBt9THsor+4A==\\n-----END CERTIFICATE-----\\n\"\n            }\n        }\n    },\n    \"peers\": {\n        \"184.172.253.205:32376\": {\n            \"url\": \"grpcs://184.172.253.205:32376\",\n            \"tlsCACerts\": {\n                \"pem\": \"-----BEGIN CERTIFICATE-----\\nMIICIjCCAcigAwIBAgIUJ6TqqfLYpjHnANNRX5G44IKWTEQwCgYIKoZIzj0EAwIw\\nYjELMAkGA1UEBhMCVVMxFzAVBgNVBAgTDk5vcnRoIENhcm9saW5hMRQwEgYDVQQK\\nEwtIeXBlcmxlZGdlcjEPMA0GA1UECxMGRmFicmljMRMwEQYDVQQDEwpPcmcyQ0Et\\ndGxzMB4XDTIwMDIyMTIwMDkwMFoXDTM1MDIxNzIwMDkwMFowYjELMAkGA1UEBhMC\\nVVMxFzAVBgNVBAgTDk5vcnRoIENhcm9saW5hMRQwEgYDVQQKEwtIeXBlcmxlZGdl\\ncjEPMA0GA1UECxMGRmFicmljMRMwEQYDVQQDEwpPcmcyQ0EtdGxzMFkwEwYHKoZI\\nzj0CAQYIKoZIzj0DAQcDQgAE9D2ZLmree+eyyRxxpoi7HN9eA2ncvG7H9MWV2zdP\\nJW0rfsP0fg+OXXYbugr9u5+zHqVVat69oTHEzaPMNtnpb6NcMFowDgYDVR0PAQH/\\nBAQDAgEGMBIGA1UdEwEB/wQIMAYBAf8CAQEwHQYDVR0OBBYEFCl6msqpbYQZN5o4\\nE1zjRENvYC/4MBUGA1UdEQQOMAyHBLis/c2HBAosDCowCgYIKoZIzj0EAwIDSAAw\\nRQIhAJXVl9u6LAH+5Fygx2wjO3spRGddMxISGtSMKd0Q1z6AAiAd29gWbYMVjtAH\\nUN563bG36yFmK2k10YkKu0XNCMralw==\\n-----END CERTIFICATE-----\\n\"\n            },\n            \"grpcOptions\": {\n                \"ssl-target-name-override\": \"184.172.253.205\"\n            }\n        }\n    },\n    \"certificateAuthorities\": {\n        \"184.172.253.205:32166\": {\n            \"url\": \"https://184.172.253.205:32166\",\n            \"caName\": \"ca\",\n            \"tlsCACerts\": {\n                \"pem\": \"-----BEGIN CERTIFICATE-----\\r\\nMIICezCCAeSgAwIBAgIJeHhsImtY0P9oMA0GCSqGSIb3DQEBBQUAMHUxGDAWBgNV\\r\\nBAMTDzE4NC4xNzIuMjUzLjIwNTELMAkGA1UEBhMCVVMxFzAVBgNVBAgTDk5vcnRo\\r\\nIENhcm9saW5hMRAwDgYDVQQHEwdSYWxlaWdoMQwwCgYDVQQKEwNJQk0xEzARBgNV\\r\\nBAsTCkJsb2NrY2hhaW4wHhcNMjAwMjIxMjAxMzI1WhcNMjEwMjIwMjAxMzI1WjB1\\r\\nMRgwFgYDVQQDEw8xODQuMTcyLjI1My4yMDUxCzAJBgNVBAYTAlVTMRcwFQYDVQQI\\r\\nEw5Ob3J0aCBDYXJvbGluYTEQMA4GA1UEBxMHUmFsZWlnaDEMMAoGA1UEChMDSUJN\\r\\nMRMwEQYDVQQLEwpCbG9ja2NoYWluMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKB\\r\\ngQCZulKdrVN4Kr0xPMBZhxHBtIZSQg1NTcFfwVCeDO1niVf0CEzm3bK6fZcR5sPg\\r\\n1V5RNN9e1KfD6SJBbGZi7igzpBKSkDQP3wMVQgT0mI9azhq03cx5pAiOD+OXWVmD\\r\\nuLn8e8yslyhRwGCweuoVtb9oIrr70CO1HlMI8bHTNUBsSwIDAQABoxMwETAPBgNV\\r\\nHREECDAGhwS4rP3NMA0GCSqGSIb3DQEBBQUAA4GBAHuXf48qyB+ol+lrBMSW0Tsl\\r\\nmI0XQoYiXVFTGZ8efy9mwNlJnma0j2aTljQLZuev9/evYSwbttqVY0u70pOulZ6l\\r\\njEnhViDWxbXr18u4oJdQfdSoSJEP1Ob2laF0aRroWs3k+otwYtXFsz36S7pqyeqS\\r\\nNqoaqvy9mzDTy9FgRVHy\\r\\n-----END CERTIFICATE-----\\r\\n\"\n            }\n        }\n    }\n}";
    private static String certificate = "-----BEGIN CERTIFICATE-----\nMIIB6jCCAZGgAwIBAgIUJQIsczakrHQwazzklBVf9k/sxNwwCgYIKoZIzj0EAwIw\naDELMAkGA1UEBhMCVVMxFzAVBgNVBAgTDk5vcnRoIENhcm9saW5hMRQwEgYDVQQK\nEwtIeXBlcmxlZGdlcjEPMA0GA1UECxMGRmFicmljMRkwFwYDVQQDExBmYWJyaWMt\nY2Etc2VydmVyMB4XDTIwMDIyNTE2MzQwMFoXDTIxMDIyNDE2MzkwMFowITEPMA0G\nA1UECxMGY2xpZW50MQ4wDAYDVQQDEwVhZG1pbjBZMBMGByqGSM49AgEGCCqGSM49\nAwEHA0IABI2d4chg3mtzku1Nxe8qo2RVIi9kESj4w7CgE1JjnwrlY/hfNRKDrcVT\njLLEtVPK2ZH4Sv/V4genK4AtX/u7j76jYDBeMA4GA1UdDwEB/wQEAwIHgDAMBgNV\nHRMBAf8EAjAAMB0GA1UdDgQWBBStczmIh8cQLZwPtDzxx+tCONKVnzAfBgNVHSME\nGDAWgBThFKVA7MNpleZSZDqJZsyEUr8kuDAKBggqhkjOPQQDAgNHADBEAiApWzXO\nqa0IXPEP82vf5ETgJ18Q4ivx8/Bq4e9+PZbXbgIgdygrkMbn6clF2PRLgYTZUjMs\nazviwY90Dd5ezvUifMs=\n-----END CERTIFICATE-----\n";
    private static StringReader certificateRdr = new StringReader(certificate);
    private static String privateKey = "-----BEGIN PRIVATE KEY-----\n" +
        "MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgZLsKmPSz+DBEK7dv\n"+
        "04onf8TacJmvd4m+FpWtQOP6xdqhRANCAASNneHIYN5rc5LtTcXvKqNkVSIvZBEo\n"+
        "+MOwoBNSY58K5WP4XzUSg63FU4yyxLVTytmR+Er/1eIHpyuALV/7u4++\n"+
        "-----END PRIVATE KEY-----";
    private static StringReader privateKeyRdr = new StringReader(privateKey);
    private static ByteArrayInputStream connIS = new ByteArrayInputStream(conn.getBytes());
    private static String mspId = "org2msp";
    private static String identity = "admin";


    public static StringReader getCertificateRdr() {
        return certificateRdr;
    }

    public static StringReader getPrivateKeyRdr() {
        return privateKeyRdr;
    }

    public static ByteArrayInputStream getConnIS() {
        return connIS;
    }

    public static String getMspId() {
        return mspId;
    }

    public static String getIdentity() {
        return identity;
    }

}