package dev.appsody.starter;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.hyperledger.fabric.gateway.Contract;
import org.hyperledger.fabric.gateway.ContractException;
import org.hyperledger.fabric.gateway.Gateway;
import org.hyperledger.fabric.gateway.Network;

@Path("/assets")
public class AssetWebservice {

    @GET
    @Path("/{id}")
    @Produces("application/json")
    public Response getAsset(@PathParam("id") String id) {
        Gateway gateway = BlockchainClient.getInstance();

        // Obtain a smart contract deployed on the network.
        Network network = gateway.getNetwork("channel1");
        Contract contract = network.getContract("tnixacontract");

        // Submit transactions that store state to the ledger.
        byte[] result = null;
        try {
            result = contract.submitTransaction("getMyAsset", id);
        } catch (ContractException | TimeoutException | InterruptedException e) {
            e.printStackTrace();
            return Response.status(Status.BAD_REQUEST).entity(new Exception("Exception issuing blockchain transaction")).build();
        }
        if ((result == null) || (result.length ==0)) {
            return Response.status(Status.NOT_FOUND).entity(new Exception("Asset not found in blockchain")).build();    
        }     
        System.out.println(new String(result, StandardCharsets.UTF_8));

        return Response.ok().entity(new String(result, StandardCharsets.UTF_8)).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes("application/json")
    @Produces("application/json")
    public Response updateAsset(@PathParam("id") String id, Asset asset) {
        Gateway gateway = BlockchainClient.getInstance();

        // Obtain a smart contract deployed on the network.
        Network network = gateway.getNetwork("channel1");
        Contract contract = network.getContract("tnixacontract");

        // Submit transactions that store state to the ledger.
        byte[] result = null;
        try {
            result = contract.submitTransaction("updateMyAsset", id, asset.getAssetValue());
        } catch (ContractException | TimeoutException | InterruptedException e) {
            e.printStackTrace();
            return Response.status(Status.BAD_REQUEST).entity(new Exception("Exception issuing blockchain transaction")).build();
        }
        if ((result == null) || (result.length ==0)) {
            return Response.status(Status.NOT_FOUND).entity(new Exception("Asset not found in blockchain")).build();    
        }     
        System.out.println(new String(result, StandardCharsets.UTF_8));

        return Response.ok().entity(new String(result, StandardCharsets.UTF_8)).build();
    }

    @DELETE
    @Path("/{id}")
    @Produces("application/json")
    public Response updateAsset(@PathParam("id") String id) {
        Gateway gateway = BlockchainClient.getInstance();

        // Obtain a smart contract deployed on the network.
        Network network = gateway.getNetwork("channel1");
        Contract contract = network.getContract("tnixacontract");

        // Submit transactions that store state to the ledger.
        byte[] result = null;
        try {
            result = contract.submitTransaction("deleteMyAsset", id);
        } catch (ContractException | TimeoutException | InterruptedException e) {
            e.printStackTrace();
            return Response.status(Status.BAD_REQUEST).entity(new Exception("Exception issuing blockchain transaction")).build();
        }
        if ((result == null) || (result.length ==0)) {
            return Response.status(Status.NOT_FOUND).entity(new Exception("Asset not found in blockchain")).build();    
        }     
        System.out.println(new String(result, StandardCharsets.UTF_8));

        return Response.ok().entity(new String(result, StandardCharsets.UTF_8)).build();
    }    

    @POST
    @Consumes("application/json")
    @Produces("application/json")
    public Response createAsset(Asset asset) {
        Gateway gateway = BlockchainClient.getInstance();

        // Obtain a smart contract deployed on the network.
        Network network = gateway.getNetwork("channel1");
        Contract contract = network.getContract("tnixacontract");

        // Submit transactions that store state to the ledger.
        byte[] result = null;
        try {
            result = contract.submitTransaction("createMyAsset", asset.getAssetName(), asset.getAssetValue());
        } catch (ContractException | TimeoutException | InterruptedException e) {
            e.printStackTrace();
            return Response.status(Status.BAD_REQUEST).entity(new Exception("Exception issuing blockchain transaction")).build();
        }
            System.out.println(new String(result, StandardCharsets.UTF_8));
   
        return Response.ok().entity(asset).build();
    }
  
}